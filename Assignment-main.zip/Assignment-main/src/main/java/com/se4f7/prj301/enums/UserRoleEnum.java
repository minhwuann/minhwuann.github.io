package com.se4f7.prj301.enums;

public enum UserRoleEnum {
	ADMIN, USER
}
