var defaultPageSize = 10;
var defaultOpts = {
	totalPages: 1
};
var domain = "http://localhost:8080/study-with-me";