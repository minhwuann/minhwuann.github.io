INSERT INTO `messages` (`id`, `subject`, `email`, `createdDate`, `updatedDate`, `createdBy`, `updatedBy`, `status`, `message`) VALUES
	(1, 'Report issues 1', 'khangnld@gmail.com', '2024-07-12 21:28:34', '2024-07-23 21:40:07', 'admin', NULL, 'ACTIVE', 'We found some bugs on screens news.'),
	(2, 'Report issues 2', 'abc@gmail.com', '2024-06-23 21:37:47', '2024-06-23 21:37:47', 'admin', NULL, 'ACTIVE', 'We found some bugs on screens news.'),
	(3, 'Report issues 3', 'xyz@gmail.com', '2024-07-21 21:37:58', '2024-07-21 21:38:23', 'admin', NULL, 'ACTIVE', 'We found some bugs on screens news.'),
	(4, 'Report issues 4', 'qwe@gmail.com', '2024-07-02 01:39:35', '2024-07-02 01:39:35', 'admin', NULL, 'ACTIVE', 'We found some bugs on screens news.'),
	(5, 'Report issues 5', 'wasd@gmail.com', '2024-07-23 21:59:57', '2024-07-23 21:59:57', 'admin', NULL, 'ACTIVE', 'We found some bugs on screens news.');

